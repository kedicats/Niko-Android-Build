// Build a fresh ANDROID AssetBundle from the Niko mesh/texture extracted from
// the user-provided UltraFumos Niko PC package. Does NOT reuse PC UnityFS.
// Tested by static inspection only: Unity Editor is required to run this.
using System;
using System.IO;
using UnityEngine;
using UnityEditor;
using UnityEngine.Rendering;

public static class BuildNikoAndroid
{
    const string MeshFile = "Assets/NikoSource/niko.meshdata";
    const string TextureFile = "Assets/NikoSource/niko.png";
    const string GenDir = "Assets/NikoGenerated";
    const string MeshPath = GenDir + "/NikoMesh.asset";
    const string MaterialPath = GenDir + "/NikoMaterial.mat";
    const string PrefabPath = GenDir + "/NikoPlush.prefab";
    const string OutDir = "Builds/Android";
    const string BundleName = "niko_android";

    [MenuItem("Tools/Niko/Build Android AssetBundle")]
    public static void Build()
    {
        string projectRoot = Directory.GetParent(Application.dataPath).FullName;
        string meshAbsolutePath = Path.Combine(projectRoot, MeshFile);
        string textureAbsolutePath = Path.Combine(projectRoot, TextureFile);
        if (!File.Exists(meshAbsolutePath)) throw new FileNotFoundException(meshAbsolutePath);
        if (!File.Exists(textureAbsolutePath)) throw new FileNotFoundException(textureAbsolutePath);
        if (!AssetDatabase.IsValidFolder(GenDir)) AssetDatabase.CreateFolder("Assets", "NikoGenerated");

        Mesh mesh = new Mesh();
        mesh.name = "NikoMesh_Android";
        using (var rd = new BinaryReader(File.OpenRead(meshAbsolutePath)))
        {
            if (new string(rd.ReadChars(4)) != "NKMS") throw new Exception("Niko mesh format mismatch");
            int count = checked((int)rd.ReadUInt32());
            int countIndices = checked((int)rd.ReadUInt32());
            if (count <= 0 || count > 60000 || countIndices <= 0 || countIndices % 3 != 0)
                throw new Exception("Invalid vertex/index counts");
            var vertices = new Vector3[count];
            var normals = new Vector3[count];
            var uvs = new Vector2[count];
            for (int i = 0; i < count; i++)
            {
                // The source mesh was authored at ~0.034 Unity units high.
                // Scale by 20 to make a roughly 0.7-unit-tall prop.
                vertices[i] = new Vector3(rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle()) * 20f;
                normals[i] = new Vector3(rd.ReadSingle(), rd.ReadSingle(), rd.ReadSingle());
                uvs[i] = new Vector2(rd.ReadSingle(), rd.ReadSingle());
            }
            var triangles = new int[countIndices];
            for (int i = 0; i < countIndices; i++)
            {
                triangles[i] = checked((int)rd.ReadUInt32());
                if (triangles[i] < 0 || triangles[i] >= count) throw new Exception("Index outside vertex range");
            }
            mesh.indexFormat = IndexFormat.UInt16;
            mesh.vertices = vertices;
            mesh.normals = normals;
            mesh.uv = uvs;
            mesh.triangles = triangles;
            mesh.RecalculateBounds();
        }
        if (AssetDatabase.LoadAssetAtPath<Mesh>(MeshPath) != null) AssetDatabase.DeleteAsset(MeshPath);
        AssetDatabase.CreateAsset(mesh, MeshPath);

        Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(TextureFile);
        if (texture == null) throw new Exception("Texture was not imported: " + TextureFile);
        Shader shader = Shader.Find("Unlit/Texture");
        if (shader == null) shader = Shader.Find("Standard");
        if (shader == null) throw new Exception("Neither Unlit/Texture nor Standard shader was found");
        Material material = new Material(shader);
        material.name = "NikoMaterial_Android";
        material.mainTexture = texture;
        if (AssetDatabase.LoadAssetAtPath<Material>(MaterialPath) != null) AssetDatabase.DeleteAsset(MaterialPath);
        AssetDatabase.CreateAsset(material, MaterialPath);

        var go = new GameObject("NikoPlush");
        try
        {
            var filter = go.AddComponent<MeshFilter>();
            var renderer = go.AddComponent<MeshRenderer>();
            filter.sharedMesh = AssetDatabase.LoadAssetAtPath<Mesh>(MeshPath);
            renderer.sharedMaterial = AssetDatabase.LoadAssetAtPath<Material>(MaterialPath);
            // No colliders / game logic are attached. The original Skull handles pickups.
            PrefabUtility.SaveAsPrefabAsset(go, PrefabPath);
        }
        finally { UnityEngine.Object.DestroyImmediate(go); }
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        string outputAbsoluteDir = Path.Combine(projectRoot, OutDir);
        if (!Directory.Exists(outputAbsoluteDir)) Directory.CreateDirectory(outputAbsoluteDir);
        var build = new AssetBundleBuild {
            assetBundleName = BundleName,
            assetNames = new [] { PrefabPath }
        };
        var manifest = BuildPipeline.BuildAssetBundles(
            outputAbsoluteDir, new [] { build }, BuildAssetBundleOptions.ChunkBasedCompression, BuildTarget.Android);
        if (manifest == null) throw new Exception("Unity AssetBundle BuildPipeline failed");
        string produced = Path.Combine(outputAbsoluteDir, BundleName);
        if (!File.Exists(produced)) throw new FileNotFoundException("Expected Android bundle missing",produced);
        string final = Path.Combine(outputAbsoluteDir, "niko_android.bundle");
        File.Copy(produced, final, true);
        Debug.Log("Niko Android AssetBundle created at " + Path.GetFullPath(final));
    }
}
